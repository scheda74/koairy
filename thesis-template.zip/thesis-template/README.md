# thesis-template
A Latex Template for your bachelor / master thesis

Please note: This is only a template. You have to adapt the template to your thesis and discuss the structure of your thesis with your supervisor
